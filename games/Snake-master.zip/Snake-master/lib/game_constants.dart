const BOARD_SIZE = 320.0;
const PIECE_SIZE = 20.0;
const TEXT_PADDING = 32.0;
