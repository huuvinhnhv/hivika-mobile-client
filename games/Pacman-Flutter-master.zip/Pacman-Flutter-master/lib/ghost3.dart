import 'package:flutter/material.dart';

class MyGhost3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(2),
      child: Image.asset('lib/images/ghost3.png'),
    );
  }
}
