package com.example.packman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
