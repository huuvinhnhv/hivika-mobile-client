# 2048

Famous 2048 game made in Flutter

## Features

1. Store High Score
2. Colorful Grid
3. Cute Font

## TODO

1. Sliding Grid Animation (Contributions are welcome)

## Screenshot

![2048](https://github.com/anuranBarman/2048/blob/master/2048.png "2048 Game")