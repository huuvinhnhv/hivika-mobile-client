class Point {
  int x;
  int y;

  Point(this.x,this.y);
}