class MyColor {
  static int gridBackground=0xFFa2917d;
  static int gridColorTwoFour=0xFFeee4da;
  static int fontColorTwoFour=0xFF766c62;
  static int emptyGridBackground=0xFFbfafa0;
  static int gridColorEightSixtyFourTwoFiftySix=0xFFf5b27e;
  static int gridColorOneTwentyEightFiveOneTwo=0xFFf77b5f;
  static int gridColorSixteenThirtyTwoOneZeroTwoFour=0xFFecc402;
  static int gridColorWin=0xFF60d992;
  static int transparentWhite=0x80FFFFFF;
}